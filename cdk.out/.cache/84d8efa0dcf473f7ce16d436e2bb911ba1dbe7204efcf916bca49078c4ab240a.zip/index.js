const unzipper = require("unzipper");

const zipObjectUrl = process.env.s3ObjectUrl;

exports.handler = async (event) => {
  console.log("zipObjectUrl: ", zipObjectUrl);
  if (zipObjectUrl) return;
  const params = {
    Key: zip_directory + "/" + zip_file,
    Bucket: input_bucket,
  };

  const zip = s3
    .getObject(params)
    .createReadStream()
    .pipe(unzipper.Parse({ forceStream: true }));

  const promises = [];

  let num = 0;

  for await (const e of zip) {
    const entry = e;

    const fileName = entry.path;
    const type = entry.type;
    if (type === "File") {
      const uploadParams = {
        Bucket: output_bucket,
        Key: output_directory + fileName,
        Body: entry,
      };

      promises.push(s3.upload(uploadParams).promise());
      num++;
    } else {
      entry.autodrain();
    }
  }

  await Promise.all(promises);
};
